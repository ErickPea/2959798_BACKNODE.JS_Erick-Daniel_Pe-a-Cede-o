function operacionAsincrona1(valor1, callback) {
    setTimeout(() => {
        const resultadoB = valor1 * 2;
        // dos argumentos
        callback(null, resultadoB);
    }, 1000);
}

// llama al operacionAsincrona 
operacionAsincrona1(5, (error, resultado1a) => {
    if (error) {
        console.error('Error:', error);
    } else {
        // Llamada a operacionAsincrona1 usando resultado1a como argumento
        operacionAsincrona1(resultado1a, (error, resultado2a) => {
            /* esta llamada se realiza solo si no hubo
            errores en la primera */
            if (error) {
                console.error('Error:', error);
            } else {
                console.log('El resultado final es:', resultado2a);
            }
        });
    }
});
