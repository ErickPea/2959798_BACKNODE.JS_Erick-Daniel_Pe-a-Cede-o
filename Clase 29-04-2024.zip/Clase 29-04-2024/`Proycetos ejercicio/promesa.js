function   operacionAsincronaSS(valor) {

    return new Promise((resolve, reject) => {

      setTimeout(() => {
        
        const resultado = valor * 2;
        resolve(resultado);
            //se hace la operacion
      }, 2000);
    });

  }
  
  // llama a laoperacionAsincrona con una promesa
  operacionAsincronaSS(7)
 //se imprime el resultado si se resolvio bien y sino saldra error 
 //
    .then(resultado => {
      console.log('El resultado es:', resultado);
    })

    .catch(error => {
      console.error('Error:', error);
    });