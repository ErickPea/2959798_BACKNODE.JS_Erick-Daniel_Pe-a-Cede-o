// operación asíncrona con async/await
function operacionAsincronaEE(valor) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const resultado = valor * 2;
           //operacion
        resolve(resultado);
      
    }, 2000);

    });
  }
  
  // llama ala función operacionAsincrona con el parametro 5
  //funcion asincronica

  async function main() {
    try {
      const resultado = await operacionAsincronaEE(10);
      console.log('El resultado es:', resultado);

    } catch (error) 
    {
      console.error('Error:', error);
    }

  }
  
  main();