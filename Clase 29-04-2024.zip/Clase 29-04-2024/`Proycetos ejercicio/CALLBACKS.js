function operacionAsincronaJJ(valor, callback) {
    setTimeout(() => {
      const resultado = valor * 2;
      callback(null, resultado);
      // se calcula el resultado se pasa null coomo primer
      //argumento y resultado como segundo
    }, 2000);
  }
  
  /*El callback toma la funcion anonima que toma dos
   parametros error, resultado
*/
    operacionAsincronaJJ(6, (error, resultado) => {
      // si en el callback el valor pasa como nulo dara error
    if (error) {
      console.error('Error:', error);
    } else {
      console.log('El resultado es:', resultado);
    }
  });
  /*si el error es null se imprime si no 
  se imprime el resultado*/ 