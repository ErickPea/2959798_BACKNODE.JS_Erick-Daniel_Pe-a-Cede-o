
function operacionAsincronaWW(valor) {

    return new Promise((resolve, reject) => {
      setTimeout(() => {
            // se hace una condicion 
        if (valor > 10) {
          const resultado = valor * 2;
          resolve(resultado);

        } else {
          const error = new Error('El valor es demasiado pequeño');
          reject(error);
                     }
          }, 2000);
    }   );
  }
  
  // llama  la función operacionAsincrona  
  // Y se le coloca como valor 5

  async function main() {
    try {
      const resultado = await operacionAsincronaWW(4);

      console.log('El resultado es:', resultado);

    } catch (error) {

      console.error('Error:', error.message);
    }
  }
  
  main();