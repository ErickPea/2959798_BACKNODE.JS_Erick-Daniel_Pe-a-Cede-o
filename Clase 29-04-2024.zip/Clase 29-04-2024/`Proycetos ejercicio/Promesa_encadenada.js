function operacionAsincronaHH(valor) {
    return new Promise((resolve, reject) => {
      
        setTimeout(() => {
        const resultado = valor * 2;
       // multiplica el valor por 2 
        resolve(resultado);
      }, 2000);

    });
  }
  
  // se llama a la función operacionAsincrona con 
  //un valor de 5  :)

  operacionAsincronaHH(8)
      
    .then(resultado1 => {
      console.log('Resultado intermedio:', resultado1);
      return operacionAsincronaHH(resultado1);
      /*se llama a operacionAsincrona pasando el
       resultado como argumrnto y asi se inicia otra operacion*/ 
    })
//esta encadenado al anterior, y cuando la segunda operacion
// se complete se imprime 
    .then(resultado2 => {
      console.log('El resultado final es:', resultado2);
    })
    .catch(error => {
      console.error('Error:', error);
    });