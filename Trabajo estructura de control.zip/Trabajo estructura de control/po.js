// Datos de ejemplo
const maestros = [
    { id: 1, nombre: 'Juan Pérez' },
    { id: 2, nombre: 'María Gómez' },
    { id: 3, nombre: 'Carlos López' }
];

const facturas = [
    { id: 1, maestroId: 1, nombre: 'Juan Pérez', total: 100 },
    { id: 2, maestroId: 2, nombre: 'María Gómez',total: 200 },
    { id: 3, maestroId: 1,  nombre: 'Juan Pérez',total: 150 }
];

const inventarios = [
    { id: 1, maestroId: 1, nombre: 'Juan Pérez', producto: 'Computadora portátil', cantidad: 10 },
    { id: 2, maestroId: 2,  nombre: 'María Gómez',producto: 'Smartphone', cantidad: 20 },
    { id: 3, maestroId: 3, nombre: 'Carlos López',producto: 'Tablet', cantidad: 15 }
];

 /*Esta función toma el nombre de un maestro 
como entrada y devuelve un objeto que contiene información detallada sobre ese maestro, 
incluyendo sus facturas y los productos en su inventario.**/
function getMaestroDetalle(nombreMaestro) {
    const maestro = maestros.find(m => m.nombre === nombreMaestro);
    const facturasDelMaestro = facturas.filter(f => f.maestroId === maestro.id);
    const inventariosDelMaestro = inventarios.filter(i => i.maestroId === maestro.id);

    return {
        maestro,
        facturas: facturasDelMaestro,
        inventarios: inventariosDelMaestro
    };
}

/* factura_detalle/ Esta función toma el ID de una factura como entrada y devuelve un objeto
 que contiene información detallada sobre esa factura, 
incluyendo el maestro asociado a ella. */
function getFacturaDetalle(facturaId) {
    const factura = facturas.find(f => f.id === facturaId);
    const maestro = maestros.find(m => m.id === factura.maestroId);

    return {
        factura,
        maestro
    };
}

/* inventario_detalle/ Esta función toma el ID de un inventario como entrada y devuelve un 
objeto que contiene información detallada sobre ese inventario,
 incluyendo el maestro asociado a él.*/
function getInventarioDetalle(inventarioId) {
    const inventario = inventarios.find(i => i.id === inventarioId);
    const maestro = maestros.find(m => m.id === inventario.maestroId);

    return {
        inventario,
        maestro
    };
}

// este es el view :) o bueno donde se muestra
console.log('Maestro_detalle:', getMaestroDetalle('Juan Pérez'));
console.log('factura_detalle:', getFacturaDetalle(2));
console.log('inventario_detalle:', getInventarioDetalle(3));
