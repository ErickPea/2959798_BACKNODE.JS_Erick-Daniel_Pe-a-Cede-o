// datos maestros (por ejemplo una lista de estudiantes)
const estudiantes = [
    // esto es un array de objetos. 
    { id: 1, nombre: 'Juan', edad: 20 },
    { id: 2, nombre: 'María', edad: 22 },
    { id: 3, nombre: 'Pedro', edad: 19 }
  ];
  

  // datos de detalle (por ejemplo: las calificaciones de cada estudiante)
  const calificaciones = [
    { estudianteId: 1, materia: 'Matemáticas', calificacion: 85 },
    { estudianteId: 1, materia: 'Historia', calificacion: 92 },
    { estudianteId: 2, materia: 'Matemáticas', calificacion: 78 },
    { estudianteId: 2, materia: 'Química', calificacion: 90 },
    { estudianteId: 3, materia: 'Historia', calificacion: 72 },
    { estudianteId: 3, materia: 'Biología', calificacion: 88 }
  ];
  
  // función para obtener las calificaciones de un estudiante
  function obtenerCalificacionesEstudiante(estudianteId) {
    /*esta funcion  toma como parámetro el id de un estudiante y devuelve un array con las calificaciones asociadas a ese
     estudiante filtrando el array calificaciones para obtener solo las calificaciones 
     que tengan el mismo estudianteId. */
    const calificacionesEstudiante = calificaciones.filter(
      calificacion => calificacion.estudianteId === estudianteId
    );
    return calificacionesEstudiante;
  }
  
  // estructura de control lógica: bucle for para iterar sobre los estudiantes
  for (const estudiante of estudiantes) {
    console.log(`Estudiante: ${estudiante.nombre}`);
  
    // obtener las calificaciones del estudiante
    const calificacionesEstudiante = obtenerCalificacionesEstudiante(estudiante.id);
  
    // estructura de control lógica: bucle for...of para iterar sobre las calificaciones
    for (const calificacion of calificacionesEstudiante) {
      console.log(`  Materia: ${calificacion.materia}, Calificación: ${calificacion.calificacion}`);
    }
  
    // estructura de control lógica: condicional if para calcular el promedio
    let suma = 0;
    for (const calificacion of calificacionesEstudiante) {
      suma += calificacion.calificacion;
    }
    const promedio = suma / calificacionesEstudiante.length;
    console.log(`  Promedio: ${promedio}`);
  }